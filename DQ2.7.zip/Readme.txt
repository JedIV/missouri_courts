DroidQuest Installaiton notes


(1) DroidQuest requires the latest version of the Java Runtime Engine to run.
    You can get this for free at...

    http://java.sun.com/products/jdk/1.3/jre/index.html


(2) Extracting the file DQ2.6.zip will produce the following:
    DQ.jar
    Readme.txt   <This File>
    images/      <A directory of JPEG & GIF files>
    sounds/      <A directory of WAV and MID files>
    chips/       <A directory of .CHIP files>


(3) To run the program, type the following command at the prompt

    java -jar DQ.jar

    Or if you are running under Windows 95/98/ME, you can simply
    double-click on the DQ.jar file icon.

    If DroidQuest doesn't come up, run it from the command prompt and send 
    me the error messages at...

    tfoote@sentinels.org

    ... and I'll see what I can do.


(4) DroidQuest automatically creates several ".lvl" files when you run it.
    This is normal. Development verisons of these files are not considered
    to be compatable with old versions, but versions within a major version
    level(version 1.x, version 2.x, etc) should be compatable.


(5) Commands are as follows:

    Cursor Keys (Up,Down,Left,Right) move the Cursor
    Control-Cursor Keys move the Cursor in small steps.
    S = Switch to Soldering Pen
    R = Toggle Remote
    C = Switch to Cursor
    T = Summon Toolbox, Open/Close Toolbox
    Space = Cursor picks up/drops object
          = Soldering Pen creates wire/attaches wire/drops wire
          = Remote toggles electrcity
    [ = Cursor rotates item Left
    ] = Cursor rotates item Right
    H = Sets the Cursor Hot/Cold in the Innovation Lab
    Shift-Up   = Increase the Chip Speed Display
    Shift-Down = Decrease the Chip Speed Display
    F = Flip wires or gates
    E = Enter enterable object
    X = Exit object
    Q = Speed game
    W = Slow game
    M = Send Memory report to standard output

(6) You CAN use the mouse to control the cursor, but because DroidQuest 
    is based on a program that was written long before the customary mouse 
    behaviors were settled upon, and the mouse controls are adapted on 
    top of that, the mouse beavior is different from how you may expect 
    the mouse to work.

    Left-Click        = Move Cursor to position where the mouse was clicked.
    Double-Left-Click = Start Cursor auto-moving in the direction towards 
                        the position of the double-click, and continue until
                        hitting a wall or exiting the room.
    Right-Click       = Like the Spacebar. Pickup/Drop, Wire/Unwire, Toggle
                        Electricity

